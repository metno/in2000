rm -rf data/*
