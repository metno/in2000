The stress test tool can be started from inside the folder with `./start.sh <prefix-for-output-files>`, the parameter is mandatory.

To set it with different configuration, edit the `config.cfg` file.

To clean up the output folder run `./cleanup.sh`.

Requires sudo capabilities for starting Docker engine.
